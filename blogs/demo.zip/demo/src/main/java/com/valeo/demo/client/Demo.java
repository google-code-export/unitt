package com.valeo.demo.client;


import com.google.gwt.core.client.EntryPoint;
import com.google.gwt.dom.client.Document;
import com.google.gwt.dom.client.LinkElement;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.ui.*;


public class Demo implements EntryPoint, ClickHandler {
    private DeckPanel root;
    private String cssId;

    public void onModuleLoad() {
        try {
            root = new DeckPanel();
            root.add(createChoices());
            root.add(createWholesalePanel());
            root.showWidget(0);
            RootPanel.get().add(root);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public Widget createChoices() {
        HorizontalPanel panel = new HorizontalPanel();
        panel.setHorizontalAlignment(HasHorizontalAlignment.ALIGN_CENTER);
        Button button = new Button("Show Customer #1");
        button.addClickHandler(this);
        panel.add(button);
        button = new Button("Show Customer #2");
        button.addClickHandler(this);
        panel.add(button);
        return panel;
    }

    public Widget createWholesalePanel() {
        VerticalPanel panel = new VerticalPanel();
        panel.setWidth("100%");
        panel.setHorizontalAlignment(HasHorizontalAlignment.ALIGN_CENTER);
        panel.addStyleName("boxBg");
        Label label = new Label("Customer Branded Contents");
        label.addStyleName("boxFg");
        panel.add(label);
        Button button = new Button("Show Choices");
        button.addClickHandler(this);
        panel.add(button);
        return panel;
    }

    public void onClick(ClickEvent event) {
        Button button = (Button) event.getSource();
        String buttonText = button.getText();
        if ("Show Choices".equals(buttonText)) {
            showChoices();
        } else {
            applyBranding(buttonText.substring(buttonText.length() - 1));
        }
    }

    protected void showChoices() {
        root.showWidget(0);
    }

    protected void applyBranding(String aCustNo) {
        root.showWidget(1);
        LinkElement styleEl = (LinkElement) Document.get().getElementById(cssId).cast();
        boolean needsInsert = false;
        if (styleEl == null) {
            styleEl = Document.get().createLinkElement();
            styleEl.setRel("stylesheet");
            styleEl.setType("text/css");
            styleEl.setId(cssId);
            needsInsert = true;
        }
        styleEl.setHref("Cust" + aCustNo + ".css");
        if (needsInsert) {
            Document.get().getElementsByTagName("head").getItem(0).appendChild(styleEl);
        }
    }
}